﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;


namespace AskDigitalTechTestJByfield
{
    public enum BrowserType
    {
        IE,
        Remote,
        FireFox,
        Chrome,
        ChromeHeadless,
        NA
    }

    public class Hooks : Base
    {
        private readonly BrowserType _browserType;
        //private readonly string _url;

        public Hooks(BrowserType browserType/*, string url*/)
        {
            _browserType = browserType;
            //_url = url;
        }

        [SetUp]
        public void InitalizeTest()
        {
            ChooseDriverInstance(_browserType);
            /*
            if (_browserType != BrowserType.NA)
            {
                if (_url != "" || _url != string.Empty)
                {
                    LaunchWebsite(_url);
                }
            }
            */
        }

        [TearDown]
        public void TearDownTest()
        {
            WebDriver.Quit();
        }

        public void ChooseDriverInstance(BrowserType browserType)
        {
            if (browserType == BrowserType.Chrome)
            {
                //ChromeOptions chromeOptions = new ChromeOptions();
                //chromeOptions.AddArguments("--disable-extensions");
                //WebDriver = new ChromeDriver(AppDomain.CurrentDomain.BaseDirectory + "Driver");
                WebDriver = new ChromeDriver();
                Wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(20));
            }
            if (browserType == BrowserType.ChromeHeadless)
            {
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.AddArguments("--window-size=1920,1080");
                chromeOptions.AddArguments("--start-maximized");
                chromeOptions.AddArguments("--headless");
                WebDriver = new ChromeDriver(chromeOptions);
                Wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(20));
            }
            if (browserType == BrowserType.FireFox)
            {
                WebDriver = new FirefoxDriver();
                WebDriver.Manage().Window.Maximize();
                Wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(20));
            }
            if (browserType == BrowserType.IE)
            {
                var options = new InternetExplorerOptions
                {
                    IntroduceInstabilityByIgnoringProtectedModeSettings = true,
                    IgnoreZoomLevel = true,
                    RequireWindowFocus = true,
                    EnsureCleanSession = true
                };
                WebDriver = new InternetExplorerDriver(AppDomain.CurrentDomain.BaseDirectory, options);
                WebDriver.Manage().Window.Maximize();
                Wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(20));
            }
            if (browserType == BrowserType.NA) { }
            if (browserType == BrowserType.Remote)
            {
                var options = new InternetExplorerOptions
                {
                    IntroduceInstabilityByIgnoringProtectedModeSettings = true,
                    IgnoreZoomLevel = true,
                    EnsureCleanSession = true,
                    RequireWindowFocus = true
                };
                WebDriver = new RemoteWebDriver(new Uri("http://10.8.130.9:4444/wd/hub"), options);
                WebDriver.Manage().Window.Maximize();
                Wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(20));
            }
        }

        /*
        private void LaunchWebsite(string url)
        {
            WebDriver.Navigate().GoToUrl(url);
        }
        */
    }
}
