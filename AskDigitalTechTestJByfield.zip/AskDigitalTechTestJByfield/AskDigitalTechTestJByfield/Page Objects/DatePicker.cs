﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;

namespace AskDigitalTechTestJByfield
{
    public class DatePicker
    {
        public DatePicker()
        {
            PageFactory.InitElements(Base.WebDriver, this);
        }

        //page objects 

        [FindsBy(How = How.Id, Using = "datePickerMonthYearInput")]
        public IWebElement DateField { get; set; }

        //Test Methods 

        public void GotoWebpage()
        {
            Base.WebDriver.Navigate().GoToUrl("https://demoqa.com/date-picker");
            Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(DateField));
        }

        public void SetDateMonthAhead()
        {
            //DateTime month = DateTime.Today.AddMonths(1).Date;
            string month = DateTime.Today.AddMonths(1).Date.ToString("MM/dd/yyyy");

            DateField.Click();
            DateField.SendKeys(Keys.Control+ "a");
            DateField.SendKeys(Keys.Backspace);
            
            //DateField.Clear();
            DateField.SendKeys(month);
        }
    }
}
