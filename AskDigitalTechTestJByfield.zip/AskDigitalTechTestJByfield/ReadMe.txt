Jonathan Byfield
Tecnical test for Answer Digital 
Date: 27/07/2021

To keep the files down to a manageable size I have had to delete the packages. 
To reinstall them, just build the solution. 

Each of the tests have been numbered with a small note (commented out) about which test is which. 
I've written these using Page Object Models and Nunit as a framework.