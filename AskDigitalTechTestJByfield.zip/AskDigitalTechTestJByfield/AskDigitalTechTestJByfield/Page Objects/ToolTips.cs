﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;

namespace AskDigitalTechTestJByfield
{
    public class ToolTips
    {
        public ToolTips()
        {
            PageFactory.InitElements(Base.WebDriver, this);
        }

        //page objects 

        [FindsBy(How = How.Id, Using = "toolTipButton")]
        public IWebElement HoverButton { get; set; }

        [FindsBy(How = How.Id, Using = "toolTipTextField")]
        public IWebElement HoverField { get; set; }

        //Test Method 

        public void GotoWebpage()
        {
            Base.WebDriver.Navigate().GoToUrl("https://demoqa.com/tool-tips");
            Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(HoverButton));
        }

        public void HoverOverButton()
        {
            Actions action = new Actions(Base.WebDriver);
            action.MoveToElement(HoverButton).Build().Perform();
            Thread.Sleep(2000);
        }

        public void HoverOverField()
        {
            Actions action = new Actions(Base.WebDriver);
            action.MoveToElement(HoverField).Build().Perform();
            Thread.Sleep(2000);
        }

    }
}
