﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;

namespace AskDigitalTechTestJByfield
{
    public class ModalPage
    {
        public ModalPage()
        {
            PageFactory.InitElements(Base.WebDriver, this);
        }

        //page objects 

        [FindsBy(How = How.Id, Using = "showSmallModal")]
        public IWebElement SmallModal { get; set; }

        [FindsBy(How = How.Id, Using = "closeSmallModal")]
        public IWebElement CloseSmallModal { get; set; }

        //Test Methods 

        public void GotoWebpage()
        {
            Base.WebDriver.Navigate().GoToUrl("https://demoqa.com/modal-dialogs");
            Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(SmallModal));
        }

        public void OpenCloseSmallModal()
        {
            SmallModal.Click();
            Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(CloseSmallModal));
            Thread.Sleep(2000);
            CloseSmallModal.Click(); 
        }
    }
}
