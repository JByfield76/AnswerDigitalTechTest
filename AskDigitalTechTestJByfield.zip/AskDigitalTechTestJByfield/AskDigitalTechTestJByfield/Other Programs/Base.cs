﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;


namespace AskDigitalTechTestJByfield
{
    public class Base
    {
        public static IWebDriver WebDriver { get; set; }
        public static WebDriverWait Wait { get; set; }
        public static IAlert Alert { get; set; }
    }
}
