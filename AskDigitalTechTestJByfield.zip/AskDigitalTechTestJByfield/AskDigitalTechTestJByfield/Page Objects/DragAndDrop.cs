﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;

namespace AskDigitalTechTestJByfield
{
    public class DragAndDrop
    {
        public DragAndDrop()
        {
            PageFactory.InitElements(Base.WebDriver, this);
        }

        //page objects 

        [FindsBy(How = How.Id, Using = "draggable")]
        public IWebElement DragMe { get; set; }

        [FindsBy(How = How.Id, Using = "droppable")]
        public IWebElement Drop { get; set; }

        //Test Methods

        public void GotoWebpage()
        {
            Base.WebDriver.Navigate().GoToUrl("https://demoqa.com/droppable");
            Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(DragMe));
        }

        public void DragToTarget()
        {
            Actions action = new Actions(Base.WebDriver);
            IAction dragAndDrop = action.ClickAndHold(DragMe).MoveToElement(Drop).Release(DragMe).Build();
            dragAndDrop.Perform();
            Thread.Sleep(2000);
        }


    }
}
