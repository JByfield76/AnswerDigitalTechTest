﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;

namespace AskDigitalTechTestJByfield
{
    public class AlertsPage
    {
        public AlertsPage()
        {
            PageFactory.InitElements(Base.WebDriver, this);
        }

        //page objects

        [FindsBy(How = How.Id, Using = "timerAlertButton")]
        public IWebElement AlertButton { get; set; }

        //Test Methods

        public void GotoWebpage()
        {
            Base.WebDriver.Navigate().GoToUrl("https://demoqa.com/alerts");
            Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(AlertButton));
        }

        public void ClickAlert()
        {
            AlertButton.Click(); 
        }

        public void AcceptAlert()
        {
            Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.AlertIsPresent()); 
            Base.WebDriver.SwitchTo().Alert();
            Base.Alert.Accept(); 
        }
    }
}
