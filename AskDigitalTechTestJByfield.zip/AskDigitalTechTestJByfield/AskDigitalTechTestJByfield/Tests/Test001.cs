﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;


namespace AskDigitalTechTestJByfield
{
    public class Test001 : Hooks

    //Enter all details into the student registration form and submit

    {
        public Test001() : base(
           (BrowserType)Enum.Parse(typeof(BrowserType),
               TestContext.Parameters["BrowserType"].ToString()))
               
        { }

        [Test]

        public void Test001Method()
        {
            Page.StudentRegistrationForm.GotoWebpage();
            Page.StudentRegistrationForm.InsertName("Jonathan","Byfield");
            Page.StudentRegistrationForm.InsertEmailGenderMobile("test@test.com","1234");
            Page.StudentRegistrationForm.SelectMale();

            Page.StudentRegistrationForm.InsertDoB("01 Jan 1990"); 

            Page.StudentRegistrationForm.InsertSubject("Computing");
            Page.StudentRegistrationForm.SelectSports(); 
           
            Thread.Sleep(5000); 
        }
    }
}
