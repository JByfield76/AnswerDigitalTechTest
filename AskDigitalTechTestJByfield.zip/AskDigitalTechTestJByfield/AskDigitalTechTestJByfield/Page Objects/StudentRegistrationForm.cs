﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;


namespace AskDigitalTechTestJByfield
{
    public class StudentRegistrationForm
    {
        public StudentRegistrationForm()
        {
            PageFactory.InitElements(Base.WebDriver, this);
        }

        //page objects 

        [FindsBy(How = How.Id, Using = "firstName")]
        public IWebElement FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "lastName")]
        public IWebElement LastName { get; set; }

        [FindsBy(How = How.Id, Using = "userEmail")]
        public IWebElement UserEmail { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div/div[2]/div[2]/div[1]/form/div[3]/div[2]/div[1]/label")] 
        //[FindsBy(How = How.Id, Using = "gender-radio-1")] 
        public IWebElement MaleRadioButton { get; set; }

        [FindsBy(How = How.Id, Using = "userNumber")]
        public IWebElement Mobile { get; set; }

        [FindsBy(How = How.Id, Using = "dateOfBirthInput")]
        public IWebElement DoB { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div/div[2]/div[2]/div[1]/form/div[5]/div[2]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[1]/select")]
        public IWebElement Month { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div/div[2]/div[2]/div[1]/form/div[5]/div[2]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[2]/select")]
        public IWebElement Year { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id=\"subjectsContainer\"]")]
        public IWebElement Subject { get; set; }

        [FindsBy(How = How.Id, Using = "hobbies-checkbox-1")]
        public IWebElement Sports { get; set; }

        [FindsBy(How = How.Id, Using = "uploadPicture")]
        public IWebElement BrowseButton { get; set; }

        [FindsBy(How = How.Id, Using = "currentAddress")]
        public IWebElement CurrentAddress { get; set; }

        [FindsBy(How = How.Id, Using = "submit")]
        public IWebElement SubmitButton { get; set; }


        //Test Methods

        public void GotoWebpage()
        {
            Base.WebDriver.Navigate().GoToUrl("https://demoqa.com/automation-practice-form");
            Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(SubmitButton));
        }

        public void InsertName(string firstName, string lastName)
        {
            FirstName.Clear();
            FirstName.SendKeys(firstName);

            LastName.Clear();
            LastName.SendKeys(lastName); 
        }

        public void InsertEmailGenderMobile(string email, string mobile)
        {
            UserEmail.Clear();
            UserEmail.SendKeys(email);

            Mobile.Clear();
            Mobile.SendKeys(mobile);
        }

        public void SelectMale()
        {
            MaleRadioButton.Click(); 
        }

        public void InsertDoB(string dob)
        {
            DoB.Click();
            DoB.SendKeys(Keys.Control + "a");
            DoB.SendKeys(dob);
            DoB.SendKeys(Keys.Return); 
        }
              
        public void InsertSubject(string subject)
        {
            //Base.Wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(Subject));
            //Subject.Click();
            Subject.Clear();
            Subject.SendKeys(subject);
        }

        public void SelectSports()
        {
            Sports.Click(); 
        }





    }
}
