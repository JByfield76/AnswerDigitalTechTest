﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;
using System.Threading;
using SeleniumExtras.WaitHelpers;
using SeleniumExtras.PageObjects;
using NUnit.Framework;


namespace AskDigitalTechTestJByfield
{
    public class Page
    {
        private static T GetPage<T>() where T : new()
        {
            var page = new T();
            PageFactory.InitElements(Base.WebDriver, page);
            return page;
        }

        public static StudentRegistrationForm StudentRegistrationForm
        {
            get { return GetPage<StudentRegistrationForm>(); }
        }

        public static AlertsPage AlertsPage
        {
            get { return GetPage<AlertsPage>(); }
        }

        public static ToolTips ToolTips
        {
            get { return GetPage<ToolTips>(); }
        }

        public static DragAndDrop DragAndDrop
        {
            get { return GetPage<DragAndDrop>(); }
        }

        public static ModalPage ModalPage
        {
            get { return GetPage<ModalPage>(); }
        }

        public static DatePicker DatePicker
        {
            get { return GetPage<DatePicker>(); }
        }

    }
}
